﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupa4_TicTacToe
{
    public class ComputerPlayer : Player
    {
        public void PlayerComputer()
        {
            Console.WriteLine("Would you like to play against computer?");

            
        }

        public void GetPlayerName()
        {
            Name = "BestPlayer";
        }
    }
}
